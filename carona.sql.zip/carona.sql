-- phpMyAdmin SQL Dump
-- version 4.4.13.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 16-Mar-2016 às 13:40
-- Versão do servidor: 5.6.28-0ubuntu0.15.10.1
-- PHP Version: 5.6.11-1ubuntu3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `carona`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `caronas`
--

CREATE TABLE IF NOT EXISTS `caronas` (
  `id` int(11) NOT NULL,
  `rua` varchar(45) DEFAULT NULL,
  `num` varchar(45) DEFAULT NULL,
  `bairro` varchar(45) DEFAULT NULL,
  `cidade` varchar(45) DEFAULT NULL,
  `dia` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `veiculo` varchar(45) DEFAULT NULL,
  `vaga` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `caronas`
--

INSERT INTO `caronas` (`id`, `rua`, `num`, `bairro`, `cidade`, `dia`, `hora`, `veiculo`, `vaga`, `user_id`) VALUES
(14, 'Rua Sagrado CoraÃ§Ã£o de Maria', '163', 'Cutucum', 'SÃ£o Domingos do Prata', '2016-04-16', '13:20:00', 'carro', 2, 11),
(15, 'Rua SÃ£o Domingos do Prata', '12', 'centro', 'Belo Horizonte', '2016-05-16', '13:27:00', 'moto', 1, 12);

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `nome` varchar(45) DEFAULT NULL,
  `role` varchar(45) DEFAULT NULL,
  `cel` varchar(45) DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `nome`, `role`, `cel`, `username`, `password`) VALUES
(11, 'Lucio', 'admin', '92877805', 'lucio', '$2a$10$8tZmox29QKmF9XmKg6dmj.XkQWH5sJFBN/bcjOkjbsm0YiZGm2GeW'),
(12, 'Lucas', 'author', '97126022', 'lucas', '$2a$10$BvRoZ8KtmUn5F.lsPl2kc.wCOoBcpn3tPRhx.bLbDbttQADxkQitK'),
(13, 'Pedro', 'admin', '99999999', 'pedro', '$2a$10$w.qi700W8T6ad/6IvYm9ceU65enkZetyEsUtdkjqsoxmFqj7lHg26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `caronas`
--
ALTER TABLE `caronas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_Carona_usuarios_idx` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `caronas`
--
ALTER TABLE `caronas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `caronas`
--
ALTER TABLE `caronas`
  ADD CONSTRAINT `fk_Carona_usuarios` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

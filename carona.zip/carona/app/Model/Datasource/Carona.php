<?php
App::uses('AppModel', 'Model');
/**
 * Carona Model
 *
 */
class Carona extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	//public $useTable = 'carona';

/**
 * Primary key field
 *
 * @var string
 */
	//public $primaryKey = 'idcarona';

/**
 * Display field
 *
 * @var string
 */
	//public $displayField = 'idcarona';

/**
 * Validation rules
 *
 * @var array
 */
	public $validate = array(
		'id' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'user_id' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
	);

public function isOwnedBy($post, $user) {
    return $this->field('id', array('id' => $post, 'user_id' => $user)) === $post;
}
}

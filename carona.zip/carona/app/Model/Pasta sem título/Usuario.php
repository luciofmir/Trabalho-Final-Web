<?php
App::uses('AppModel', 'Model');
/**
 * Usuario Model
 *
 */
class Usuario extends AppModel {

/**
 * Primary key field
 *
 * @var string
 */
	public $primaryKey = 'idusuarios';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'idusuarios';

/**
 * Validation rules
 *
 * @var array
 */
	public $validate = array(
		'idusuarios' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
	);
}

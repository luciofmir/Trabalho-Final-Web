<?php
App::uses('AppModel', 'Model');
/**
 * Carona Model
 *
 */
class Carona extends AppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'Carona';

/**
 * Primary key field
 *
 * @var string
 */
	public $primaryKey = 'idcarona';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'idcarona';

/**
 * Validation rules
 *
 * @var array
 */
	public $validate = array(
		'idcarona' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'usuarios_idusuarios' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
	);
}

<?php
App::uses('AppModel', 'Model');

class Sobre extends AppModel {


}

<?php
App::uses('Carona', 'Model');

/**
 * Carona Test Case
 */
class CaronaTest extends CakeTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.carona'
	);

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();
		$this->Carona = ClassRegistry::init('Carona');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->Carona);

		parent::tearDown();
	}

}

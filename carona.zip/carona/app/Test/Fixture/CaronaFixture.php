<?php
/**
 * Carona Fixture
 */
class CaronaFixture extends CakeTestFixture {

/**
 * Table name
 *
 * @var string
 */
	public $table = 'Carona';

/**
 * Fields
 *
 * @var array
 */
	public $fields = array(
		'idcarona' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false, 'key' => 'primary'),
		'rua' => array('type' => 'string', 'null' => true, 'default' => null, 'length' => 45, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
		'num' => array('type' => 'string', 'null' => true, 'default' => null, 'length' => 45, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
		'bairro' => array('type' => 'string', 'null' => true, 'default' => null, 'length' => 45, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
		'cidade' => array('type' => 'string', 'null' => true, 'default' => null, 'length' => 45, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
		'dia' => array('type' => 'date', 'null' => true, 'default' => null),
		'hora' => array('type' => 'time', 'null' => true, 'default' => null),
		'veiculo' => array('type' => 'string', 'null' => true, 'default' => null, 'length' => 45, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
		'vagas' => array('type' => 'integer', 'null' => true, 'default' => null, 'unsigned' => false),
		'usuarios_idusuarios' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false, 'key' => 'index'),
		'indexes' => array(
			'PRIMARY' => array('column' => 'idcarona', 'unique' => 1),
			'fk_Carona_usuarios_idx' => array('column' => 'usuarios_idusuarios', 'unique' => 0)
		),
		'tableParameters' => array('charset' => 'utf8', 'collate' => 'utf8_general_ci', 'engine' => 'InnoDB')
	);

/**
 * Records
 *
 * @var array
 */
	public $records = array(
		array(
			'idcarona' => 1,
			'rua' => 'Lorem ipsum dolor sit amet',
			'num' => 'Lorem ipsum dolor sit amet',
			'bairro' => 'Lorem ipsum dolor sit amet',
			'cidade' => 'Lorem ipsum dolor sit amet',
			'dia' => '2016-03-08',
			'hora' => '19:55:47',
			'veiculo' => 'Lorem ipsum dolor sit amet',
			'vagas' => 1,
			'usuarios_idusuarios' => 1
		),
	);

}

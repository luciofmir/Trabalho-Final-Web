<?php
App::uses('AppController', 'Controller');
/**
 * Caronas Controller
 *
 * @property Carona $Carona
 * @property PaginatorComponent $Paginator
 * @property FlashComponent $Flash
 * @property SessionComponent $Session
 */
class CaronasController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator', 'Flash', 'Session');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->Carona->recursive = 0;
		$this->set('caronas', $this->Paginator->paginate());
	}


         public function isAuthorized($user) {
    // All registered users can add posts
    if ($this->action === 'add') {
        return true;
    }

    // The owner of a post can edit and delete it
    if (in_array($this->action, array('edit', 'delete'))) {
        $postId = (int) $this->request->params['pass'][0];
        if ($this->Post->isOwnedBy($postId, $user['id'])) {
            return true;
        }
    }

    return parent::isAuthorized($user);
}


/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->Carona->exists($id)) {
			throw new NotFoundException(__('Carona Inválida'));
		}
		$options = array('conditions' => array('Carona.' . $this->Carona->primaryKey => $id));
		$this->set('carona', $this->Carona->find('first', $options));
	}




/**
 * add method
 *
 * @return void
 */
public function add() {
    if ($this->request->is('post')) {
        //Added this line
        $this->request->data['Carona']['user_id'] = $this->Auth->user('id');
        
       if ($this->Carona->save($this->request->data)) {
            $this->Flash->success(__('Your post has been saved.'));
            return $this->redirect(array('action' => 'index'));
        }	
    }
}

	
/*public function add() {
		if ($this->request->is('post')) {
			$this->Carona->create();
			if ($this->Carona->save($this->request->data)) {
				$this->Flash->success(__('Carona Adicionada com Sucesso.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Flash->error(__('Tente Novamente'));
			}
		}
		//$users = $this->Carona->User->find('list');
		$users = $this->Carona->User->find('list', array('fields' => array('id', 'nome')));
		$this->set(compact('users'));
	}*/

/*public function add() {
		if ($this->request->is('post')) {
			$this->Candidate->create();
			if ($this->Candidate->save($this->request->data)) {
				$this->Session->setFlash(__('The candidate has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The candidate could not be saved. Please, try again.'));
			}
		}
		$parties = $this->Candidate->Party->find('list');
		$jobs = $this->Candidate->Job->find('list');
		$this->set(compact('parties', 'jobs'));
	}*/



/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->Carona->exists($id)) {
			throw new NotFoundException(__('Carona Inválida'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->Carona->save($this->request->data)) {
				$this->Flash->success(__('Carona Salva com Sucesso.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Flash->error(__('Tente Novamente.'));
			}
		} else {
			$options = array('conditions' => array('Carona.' . $this->Carona->primaryKey => $id));
			$this->request->data = $this->Carona->find('first', $options);
		}
		$users = $this->Carona->User->find('list');
		$this->set(compact('users'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->Carona->id = $id;
		if (!$this->Carona->exists()) {
			throw new NotFoundException(__('Carona Inválida'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->Carona->delete()) {
			$this->Flash->success(__('Carona Deletada com Sucesso.'));
		} else {
			$this->Flash->error(__('Tente Novamente.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
}

<?php
App::uses('AppController', 'Controller');

class SobreController extends AppController {


	public function index() {
		
	}

}

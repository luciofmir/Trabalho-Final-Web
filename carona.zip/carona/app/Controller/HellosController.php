<?php

class HellosController extends AppController {

  var $uses = null;

  public function index() {

  }

  public function helloWord() {
      $this->set('mensagem', 'Introducao ao CakePHP');

  }

}


?>
